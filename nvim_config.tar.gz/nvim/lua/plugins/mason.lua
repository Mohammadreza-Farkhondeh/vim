return {
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "shellcheck",
        "ruff",
	"ruff-lsp",
	"pyright"
      },
    },
  },

}
